# POSE AI

Your Personal AI Photography Director.

## iPhone-first setup

1. Open this project ZIP in a browser-based development workspace that supports Vite and npm.
2. In its terminal, run `npm install`, then `npm run dev -- --host 0.0.0.0`.
3. Open the workspace's HTTPS preview link in Safari. Camera access requires HTTPS (or localhost).
4. Add the page to the Home Screen from Safari's Share menu.
5. Open POSE AI from its new Home Screen icon and allow camera access.

For a public installation link, build with `npm run build` and publish the `dist` folder to an HTTPS static host. Camera and pose detection require a secure context. The app interface is cached for offline opening; the first pose model download requires internet. Pose photos and landmarks are kept in browser IndexedDB on this device.

## Included

- Reference image selection and on-device MediaPipe pose extraction
- Front/rear camera, live skeleton, pose similarity and Turkish coaching
- Manual and 3, 5, 10 second photo capture; download and session gallery
- IndexedDB pose library, PWA manifest and service worker

The camera and model need a real iPhone Safari session to validate device-specific permissions and performance.
